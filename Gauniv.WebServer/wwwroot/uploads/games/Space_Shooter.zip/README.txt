Space Shooter
Space Shooter Demo

Use arrow keys to move, Space to shoot!

To play:
1. Extract this ZIP file
2. Run Space_Shooter.bat

Enjoy!
