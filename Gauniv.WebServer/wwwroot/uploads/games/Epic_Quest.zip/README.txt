Epic Quest
Welcome to Epic Quest!

This is a demo adventure game.

To play:
1. Extract this ZIP file
2. Run Epic_Quest.bat

Enjoy!
