Fantasy World
Fantasy World Demo

Build your kingdom and rule the lands!

To play:
1. Extract this ZIP file
2. Run Fantasy_World.bat

Enjoy!
